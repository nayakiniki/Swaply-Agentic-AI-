import gradio as gr
from utils.database import load_users
from utils.matching import get_top_matches

users = load_users()

def show_matches(name):
    user = next((u for u in users if u["name"] == name), None)
    if not user:
        return "User not found"

    matches = get_top_matches(user, users)
    display = ""
    for match in matches:
        display += f"🧑‍🎓 {match['name']}\nHas: {', '.join(match['skills_have'])} | Wants: {', '.join(match['skills_want'])}\n\n"
    return f"Best matches for {user['name']}:\n\n{display}"

user_names = [u["name"] for u in users]

with gr.Blocks() as demo:
    gr.Markdown("# 🎯 Swaply - Skill Exchange App")

    with gr.Row():
        name_input = gr.Dropdown(label="Select Your Name", choices=user_names)
        match_output = gr.Textbox(lines=10, label="Top Matches")
        match_button = gr.Button("Find Matches")

    match_button.click(fn=show_matches, inputs=name_input, outputs=match_output)

demo.launch()
