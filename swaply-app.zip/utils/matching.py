from sentence_transformers import SentenceTransformer, util
import torch

model = SentenceTransformer('all-MiniLM-L6-v2')

def get_top_matches(current_user, all_users, top_k=3):
    scores = []
    for user in all_users:
        if user["id"] == current_user["id"]:
            continue
        score = 0
        for want in current_user["skills_want"]:
            for offer in user["skills_have"]:
                score += util.cos_sim(
                    model.encode(want, convert_to_tensor=True),
                    model.encode(offer, convert_to_tensor=True)
                ).item()
        scores.append((user, score))
    sorted_matches = sorted(scores, key=lambda x: x[1], reverse=True)
    return [user for user, _ in sorted_matches[:top_k]]
